const { GiveawaysManager } = require('discord-giveaways');
const Discord = require("discord.js")
const Fs = require("fs")
const Config = require("./Configuration/Robot.js")
const client = new Discord.Client({
    fetchAllMembers: true, 
    partials: ['MESSAGE', 'REACTION']    
    })

client.db = require("./Configuration/Avertissement.json")
client.commands = new Discord.Collection

//Système de concours ! 
client.giveawaysManager = new GiveawaysManager(client, {
    storage: "./Concours.json",
    updateCountdownEvery: 5000,
    default: {
        botsCanWin: false,
        exemptPermissions: [],
        embedColor: "#FF0000",
        reaction: "🎉"
    }
});

//Utilisation des fichiers !
Fs.readdirSync('./Commandes').forEach(dirs => {
    const commands = Fs.readdirSync(`./Commandes/${dirs}`).filter(files => files.endsWith('.js'));
    for (const file of commands) {
        const getFileName = require (`./Commandes/${dirs}/${file}`);
        console.log(`Commande : ${file}`);
        client.commands.set(getFileName.help.name, getFileName);
      }
})
const events = Fs.readdirSync('./Evenements').filter(file => file.endsWith('.js'));

for (const file of events) {
    console.log(`Event : ${file}`);
    const event = require(`./Evenements/${file}`);
    client.on(file.split(".")[0], event.bind(null, client));
}

//Allumer le bot ! + Options    
client.login(Config.Token)