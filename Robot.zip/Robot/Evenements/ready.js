module.exports = client => {            
    setInterval(() => { 
    client.user.setPresence({ activity: { name: `.help | ${client.users.cache.size} membres`, type: 'WATCHING' }, status: 'dnd' })
    }, 1000);
    
    console.log(client.user.username + " est en ligne ! 🔘");
}
    