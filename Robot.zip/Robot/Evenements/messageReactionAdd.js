const { reactionRole } = require("./../Configuration/Roles.json")

module.exports = (client, reaction, user) => {
        if (!reaction.message.guild || user.bot) return
        const reactionRoleElem = reactionRole[reaction.message.id]
        if (!reactionRoleElem) return
        const prop = reaction.emoji.id ? 'id' : 'name'
        const emoji = reactionRoleElem.emojis.find(emoji => emoji[prop] === reaction.emoji[prop])
        if (emoji) reaction.message.guild.member(user).roles.add(emoji.roles)        
}