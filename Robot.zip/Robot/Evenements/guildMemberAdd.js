const Discord = require("discord.js")
const Config = require("./../Configuration/Robot.js")

module.exports = async (client, member) => {
        const embed = new Discord.MessageEmbed()
        .setAuthor(`Bienvenue ${member.displayName}`, member.user.displayAvatarURL())
        .setFooter("Nous vous souhaitons la bienvenue sur La Galaxie Des Artistes ")              
        client.channels.cache.get(Config.ChanB).send(embed);
                        
        client.channels.cache.get(Config.ChanR).send(`${member}`).then(message => {message.delete()});    
        client.channels.cache.get(Config.ChanA).send(`${member}`).then(message => {message.delete()});               
        }