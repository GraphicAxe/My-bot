const { Prefix } = require("./../Configuration/Robot.js")

module.exports = (client, message) => {
    if (!message.content.startsWith(Prefix) || message.author.bot) return;  
    const args = message.content.slice(Prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();
    if (!client.commands.has(command)) return;
    client.commands.get(command).run (client, message, args)

}