const Discord = require("discord.js")
const Config = require("./../Configuration/Robot.js")

module.exports = (client, member) => {
        const embed = new Discord.MessageEmbed()
        .setAuthor(`${member.displayName} a quitté`, member.user.displayAvatarURL())
        
        client.channels.cache.get(Config.ChanB).send(embed);     
        }  