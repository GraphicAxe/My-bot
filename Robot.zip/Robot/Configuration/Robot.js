module.exports = {
    Prefix : ".",
    Token : "NzgyMjU4NzQyNDM0OTg4MDMy.X8JlOQ.ABZegF3Zx7B7aH4-tzwake68bs4",
    ChanB : "788429508759519243",
    ChanR : "721491427447537705",
    ChanA : "721491514005651557",
    RoleB : "713177410492956754",
    HostedBy : true, 
    everyoneMention : false, 
}