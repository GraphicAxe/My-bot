const Discord = require("discord.js")

module.exports.run = async(client,message,args)=> {
    let role = message.guild.roles.cache.find(r => r.name == 'La Galaxie Des Artistes') 
    if (!role) return message.channel.send(`**${message.author.username}**, role not found`) 
    message.guild.members.cache.forEach(member => member.roles.add(role)) 
    message.channel.send(`**${message.author.username}**, role **${role.name}** was added to all members`)
}
module.exports.help = {
    name: "roleadd",
    aliases: ["roladd"],
    category: 'general',
    description: "Donner un role",
    usage: '',
    args: false
}