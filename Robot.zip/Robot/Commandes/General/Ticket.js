const { MessageEmbed } = require("discord.js");
const discord = require('discord.js');

module.exports.run = async (client, message, args) => {
		if(!message.guild.me.hasPermission("MANAGE_CHANNELS")) {
			return message.channel.send("Je n'ai pas les permissions pour créer un salon!");
		}
		if (!args[0]) { return message.channel.send("Pour ouvrir un ticket: \n``.ticket reason``").then(m => m.delete({ timeout: 2500 }));}
		const everyone = message.guild.roles.cache.find(r => r.name == "@everyone");
		const ticketstaff = message.guild.roles.cache.find(r => r.name == "Accès billet");
		if(!ticketstaff) {
			message.guild.roles.create ({
				data:{
					name: "Accès billet",

				},
			});
			message.channel.send("Un rôle nommé 'Accès billet' a été créé pour les membres du staff.");
		}
		const memberid = message.author.tag.replace(/[^a-zA-z0-9]/g, "").trim().toLowerCase();

		if(message.guild.channels.cache.find(c => c.name.replace(/-/g, " ") == memberid)) {
			return message.channel.send("Vous avez déjà un ticket");
		}
		const tch = message.guild.channels.cache.find(c => c.name == "■ 📁 Ticket" && c.type == "category");
		if(!tch) {
			return await message.guild.channels.create("■ 📁Ticket", {
				type: "category",
			});
		}
		return message.guild.channels.create(memberid, {
			type: "text",
			permissionOverwrites: [{
					id: everyone.id,
					deny: "VIEW_CHANNEL",
				},
				{ id: ticketstaff.id,
					allow: "VIEW_CHANNEL",
				},
				{ id: message.author.id,
					allow: "VIEW_CHANNEL",
				}],
			parent: tch.id,
		}).then(c => {message.channel.send("Votre ticket a été créé !"),
		message.guild.channels.cache.find(m => m.name.replace(/-/g, " ") == memberid).send(
			("Nous avons besoin de vous <@&790677437327474700> !"),
			new MessageEmbed()
				.setDescription("Veuillez patienter que les jurés vous répondre.\n\nPoster **4 créations** ou votre **portfolio**.\n\nSi vous êtes **étudiant(e) ou professionnel(le)**, veuillez envoyer des **preuves** dans le salon !")
				.setAuthor(message.member.displayName, message.author.displayAvatarURL())
				.setTimestamp(new Date())
				.setFooter("Validation via ticket")
		);
		});
	};
module.exports.help = {
    name: "ticket",
    aliases: ["ticket"],
    category: 'general',
    description: "Ouvrir un ticket",
    usage: '<raison>',
    args: false
}
