const Discord = require("discord.js");
const fs = require('fs');

module.exports = {
    run: async (client, message, args) => {
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('Aucune permissions.')
        const member = message.mentions.members.first()
        if (!member) return message.channel.send('Veuillez mentionner le membre à warn.')
        if (member.id === message.guild.ownerID) return message.channel.send('Vous ne pouvez pas warn le propriétaire du serveur.')
        if (message.member.roles.highest.comparePositionTo(member.roles.highest) < 1 && message.author.id !== message.guild.ownerID) return message.channel.send('Vous ne pouvez pas warn ce membre.')
        const reason = args.slice(1).join(' ')
        if (!reason) return message.channel.send('Veuillez indiquer une raison.')
        if (!client.db.warns[member.id]) client.db.warns[member.id] = []
        client.db.warns[member.id].unshift({
            reason,
            date: Date.now(),
            mod: message.author.id
        })
        fs.writeFileSync('./Configuration/db.json', JSON.stringify(client.db))
        let WarnEmbed = new Discord.MessageEmbed()
           .setTitle("__**Avertissement**__")
           .setColor("#bc0000")
           .setDescription(`${member} a été averti par <@${message.author.id}>.\n\n__**Motif :**__ ${reason}`);

        let WarnChannel = message.guild.channels.cache.find(channel => channel.name === "📁・incidents")
    if (!WarnChannel) return message.channel.send("Je ne trouve pas le channel `📁・incidents` si il n'existe pas merci de bien vouloir le créer.")

    WarnChannel.send(WarnEmbed);
    },
    
},
module.exports.help = {
    name: "warn",
    aliases: ["warn"],
    category: 'moderations',
    description: "Mettre un avertissement à un utilisateur",
    usage: '<mention> <raison>',
    args: false
}