const Discord = require("discord.js")

module.exports = {
    run: async (client, message, args) => {
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('Vous n\'avez pas la permission d\'utiliser cette commande.')
        const member = message.mentions.members.first()
        if (!member) return message.channel.send('Veuillez mentionner le membre à mute.')
        if (member.id === message.guild.ownerID) return message.channel.send('Vous ne pouvez mute le propriétaire du serveur.')
        if (message.member.roles.highest.comparePositionTo(member.roles.highest) < 1 && message.author.id !== message.guild.ownerID) return message.channel.send('Vous ne pouvez pas mute ce membre.')
        if (!member.manageable) return message.channel.send('Le bot ne peut pas mute ce membre.')
        const reason = args.slice(1).join(' ') || 'Aucune raison fournie.'
        let muteRole = message.guild.roles.cache.find(role => role.name === '📆 Les membres mutés')
        if (!muteRole) {
            muteRole = await message.guild.roles.create({
                data: {
                    name: '📆 Les membres mutés',
                    permissions: 0
                }
            })
            message.guild.channels.cache.forEach(channel => channel.createOverwrite(muteRole, {
                SEND_MESSAGES: false,
                CONNECT: false,
                ADD_REACTIONS: false
            }))
        }
        await member.roles.add(muteRole)
       
       let MuteEmbed = new Discord.MessageEmbed()
       .setTitle("__**Muet**__")
       .setColor("#bc0000")
       .setDescription(`${member} a été mit en muet par <@${message.author.id}>.\n\n__**Motif :**__ ${reason}`);

        let MuteChannel = message.guild.channels.cache.find(channel => channel.name === "📁・incidents")
    if (!MuteChannel) return message.channel.send("Je ne trouve pas le channel `📁・incidents` si il n'existe pas merci de bien vouloir le créer.")

    MuteChannel.send(MuteEmbed);
    }
},
module.exports.help = {
    name: "muet",
    aliases: ["mute"],
    category: 'moderations',
    description: "Mettre en muet un utilisateur",
    usage: '*mention *raison',
    args: false
}