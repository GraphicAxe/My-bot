const Discord = require("discord.js")
const fs = require('fs')

module.exports = {
    run: async (client, message, args) => {
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('Aucune permissions.')
        const member = message.mentions.members.first()
        if (!member) return message.channel.send('Veuillez mentionner le membre à unwarn.')
        if (!client.db.warns[member.id]) return message.channel.send('Ce membre n\'a aucun warn.')
        const warnIndex = parseInt(args[1], 10) - 1
        if (warnIndex < 0 || !client.db.warns[member.id][warnIndex]) return message.channel.send('Ce warn n\'existe pas.')
        const { reason } = client.db.warns[member.id].splice(warnIndex, 1)[0]
        if (!client.db.warns[member.id].length) delete client.db.warns[member.id]
        fs.writeFileSync('./Configuration/Avertissement.json', JSON.stringify(client.db))      
    },
   
},
module.exports.help = {
    name: "unwarn",
    aliases: ["unwarn"],
    category: 'moderations',
    description: "Enlever les avertissements d'un utilisateur",
    usage: '*mention *raison',
    args: false
}