const { MessageEmbed } = require("discord.js");
const Color = `#2C2F33`;

module.exports.run = async (client, message, args) => {
    const Members = message.guild.memberCount;
    const bots = message.guild.members.cache.filter(
      member => member.bot === true
    ).size;
    const humans = message.guild.members.cache.filter(
      member => !member.user.bot
    ).size;
    const online = message.guild.members.cache.filter(
      member => member.presence.status === "online"
    ).size;
    const offline = message.guild.members.cache.filter(
      member => member.presence.status === "offline"
    ).size;
    const dnd = message.guild.members.cache.filter(
      member => member.presence.status === "dnd"
    ).size;
    const idle = message.guild.members.cache.filter(
      member => member.presence.status === "idle"
    ).size;

    const embed = new MessageEmbed()
      .setColor(`${Color}`)
      .setTitle(`Informations sur les membres`)
      .addField(`Membres`, Members)
      .addField(`Humains`, humans)
      .addField(`Robots`, bots)
      .addField(
        `Statuts des membres`,
        `En ligne: ${online} | Ne pas déranger: ${dnd} | Inactif: ${idle} | Hors-ligne: ${offline}`
      )
      .setTimestamp();

    message.channel.send(embed);
  };
module.exports.help = {
    name: "membres",
    aliases: ["membres"],
    category: 'utiles',
    description: "Afficherle nombre de membres",
    usage: '',
    args: false
}