const Discord = require("discord.js")
const { Prefix } = require ("../../Configuration/Robot.js")
const { readdirSync } = require("fs")
const categoryList = readdirSync('./Commandes')

module.exports.run = (client, message, args) => {
    if (!args.length) {
        const embed = new Discord.MessageEmbed()
        .setTitle("**Liste des commandes**")
        .setFooter(`Pour plus d'informations, tapez ${Prefix}help *command_name`)
        
        for (const category of categoryList) {
            embed.addField(
            `${category}`,
            `${client.commands.filter(cat => cat.help.category === category.toLowerCase()).map(cmd => cmd.help.name).join(', ')}`
            );
        };
        
        return message.channel.send(embed);
    } else {
        const command = client.commands.get(args[0]) || client.commands.find(cmd => cmd.help.aliases && cmd.help.aliases.included(args[0]));
        
        const embed = new Discord.MessageEmbed()
        .addField("Description:", `${command.help.description}`)
        .addField("Utilisation:", command.help.usage ? `${Prefix}${command.help.name} ${command.help.usage}` : `${command.help.name}`, true)
      
      if (command.help.aliases.length > 1) embed.addField("Alias", `${command.help.aliases.join(', ')}`, true);
    message.channel.send(embed);  
    }
};

module.exports.help = {
    name: "help",
    aliases: ["help"],
    category: 'utiles',
    description: "Donne la liste des commandes",
    usage: '*nom de la commande',
    args: false
}