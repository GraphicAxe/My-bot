const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {
    let waiting = await message.channel.send("Recherche...").catch(console.error);

    let mentionedUser = message.mentions.users.first() || message.author;

    let avatarembed = new Discord.MessageEmbed()

        .setImage(mentionedUser.displayAvatarURL())
        .setColor("#2C2F33")
        .setTitle("Avatar")
        .setFooter("Demandé par " + message.author.tag)
        .setDescription("[Lien de l'avatar](" + mentionedUser.displayAvatarURL() + ")");

    waiting.edit(avatarembed).catch(console.error)
};

module.exports.help = {
    name: "avatar",
    aliases: ["avatar"],
    category: 'utiles',
    description: "Afficher l'avatar d'un utilisateur",
    usage: '<mention>',
    args: false
};