const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {
    var serverembed = new Discord.MessageEmbed()
    var r0=message.guild.createdAt
    serverembed.setColor("#2C2F33")
    serverembed.setThumbnail(message.guild.iconURL())
    serverembed.setAuthor(message.guild.name)
    serverembed.addField("Nom", message.guild.name, 1)
    serverembed.addField("ID", message.guild.id, 1)
    serverembed.addField("Owner", message.guild.owner, 1)
    serverembed.addField("Nombre de membres",  `${message.guild.memberCount}`, 1)
    serverembed.setFooter("Créé le " + ["dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi"][r0.getDay()]+r0.getDate().toString().padStart(3," 00")+[" janvier"," fevrier"," mars"," avril"," mai"," juin"," juillet"," aout"," septembre"," octobre"," novembre"," decembre"][r0.getMonth()]+r0.getFullYear().toString().padStart(5," 0000")+r0.getHours().toString().padStart(5," à 00")+r0.getMinutes().toString().padStart(3,":00")+r0.getSeconds().toString().padStart(3,":00"));

    message.channel.send(serverembed);
    
    message.delete();
}

module.exports.help = {
    name: "serveur",
    aliases: ["serveur"],
    category: 'utiles',
    description: "Affiche les informations du serveur",
    usage: '',
    args: false
}