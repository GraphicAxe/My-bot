const Discord = require("discord.js")

module.exports.run = (client, message, args) => {
    let start = Date.now();
    
    message.channel.send({embed: {description: "Envoie de la latence entre vous et le robot.", color: "Gray"}}).then(m => {
        let end = Date.now();
        
        let embed = new Discord.MessageEmbed()
        .setAuthor("Latence", message.author.avatarURL())
        .addField("Latence de l'api : ", Math.round(client.ws.ping) + "ms", true)
        .addField("Latence du message : ", end - start + "ms", true)
        .setColor("#2C2F33");
        m.edit(embed).catch(e => message.channel.send(e))
    })
}
module.exports.help = {
    name: "ping",
    aliases: ["ping"],
    category: "utiles",
    description: "Latence entre vous et l'api",
    usage: "*mention",
    args: false 
}