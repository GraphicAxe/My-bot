module.exports.run = async (client, message, args) => {
    if (!message.member.hasPermission("MANAGE_MESSAGE")) return message.channel.send("Aucune permissions");
    
    let clientmessage = args.join(" ");
    message.delete().catch();
    message.channel.send(clientmessage)
};
module.exports.help = {
    name: "parler",
    aliases: ["parler"],
    category: 'utiles',
    description: "Envoyer un message avec le bot",
    usage: '<texte>',
    args: false
};