const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {
        let suggestion = args.slice(0).join(" ");
        let SuggestionChannel = message.guild.channels.cache.find(channel => channel.name === "📁・suggestions");
      
      if(!suggestion) {
        return message.reply("Merci de décrire votre suggestion !")
      }      
      
        const embed = new Discord.MessageEmbed()
            .setAuthor(message.guild.name, message.guild.iconURL())
            .setDescription(suggestion)
            .setFooter(`Suggestion de ${message.author.tag}`)
        
        SuggestionChannel.send(embed).then(msg => {
            msg.react("✅")
            msg.react("❎")
       
        message.channel.send("Votre suggestion a été envoyée ! ");
        });
}
module.exports.help = {
    name: "suggestion",
    aliases: ["suggestion"],
    category: 'utiles',
    description: "Émettre une suggestion",
    usage: '<texte>',
    args: false
}