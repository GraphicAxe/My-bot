const Discord = require("discord.js");
const moment = require("moment");

module.exports.run = async (client, message, args) => {
    let inline = true
    let resence = true
    const status = {
        online: "En ligne",
        idle: "Inactif",
        dnd: " Ne pas déranger",
        offline: " Hors-Ligne/Invisble"
    }
    let mentionedUser = message.mentions.users.first() || message.author;

    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    let target = message.mentions.users.first() || message.author

    if (member.user.bot === true) {
        bot = "Oui";
    } else {
        bot = "Non";
    }


    let embed = new Discord.MessageEmbed()
        .setAuthor(member.user.username)
        .setThumbnail((target.displayAvatarURL()))
        .setColor("#2C2F33")
        .addField("Pseudo", `${member.user.tag}`, inline)
        .addField("ID", member.user.id, inline)
        .addField("Statut", `${status[member.user.presence.status]}`, inline, true)
        .addField("A rejoint Discord le :", moment(member.user.createdAt).format("LL"), true)
        .setFooter(`Informations sur ${member.user.username}`)
        .addField('Arrivé sur le serveur', moment(message.guild.members.cache.get(member.id).joinedAt).format("LL"), true)
        .setThumbnail(mentionedUser.displayAvatarURL())
        .setTimestamp()

    message.channel.send(embed);

    message.delete();
}

module.exports.help = {
    name: "membre",
    aliases: ["membre"],
    category: 'utiles',
    description: "Affiche les informations d'un utilisateur",
    usage: '*mention',
    args: false
}