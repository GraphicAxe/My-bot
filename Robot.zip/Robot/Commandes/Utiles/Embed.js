const Discord = require ('discord.js')

module.exports.run = async (client, message, args) => {
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("Aucune permissions")
   await message.delete()
   
  let say = message.content.split(" ").slice(1).join(" ")
  if(!say) return message.channel.send("Message vide ?")
  let embed = new Discord.MessageEmbed()
  .setAuthor(message.guild.name, message.guild.iconURL())
  .setDescription(`${say}`)
  message.channel.send(embed)
};
module.exports.help = {
    name: "embed",
    aliases: ["embed"],
    category: 'utiles',
    description: "Créer un embed à partir d'une commande",
    usage: '*texte',
    args: false
}
