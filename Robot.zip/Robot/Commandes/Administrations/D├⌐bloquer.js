const Discord = module.require("discord.js");

module.exports.run = async (client, message, args) => {
   if (!message.member.hasPermission('MANAGE_SERVER', 'MANAGE_CHANNELS')) {
   return message.channel.send("Aucune permissions.")
   }
   message.channel.overwritePermissions([
     {
        id: message.guild.id,
        null : ['SEND_MESSAGES'],
     },
    ],);
   const embed = new Discord.MessageEmbed()
   .setTitle("Salon débloqué")
   .setDescription(`🔓 ${message.channel}  a été débloqué`)
   await message.channel.send(embed);
   message.delete();
};
module.exports.help = {
    name: "debloquer",
    aliases: ["unlock"],
    category: 'administrations',
    description: "Débloquer un salon",
    usage: '',
    args: false
}