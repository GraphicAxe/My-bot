const Discord = require("discord.js")

module.exports.run = (client, message, args) => {
        const amount = parseInt(args[0])
        if(message.member.hasPermission("MANAGE_CHANNEL"))
        if(isNaN(amount)) return message.channel.send("Veuillez mettre une valeur valide.")
        if(args[0] === amount + "s") {
        message.channel.setRateLimitPerUser(amount)
        if(amount > 1) {
        message.channel.send("Le mode lent est de " + amount + " secondes")
        return
        }
        else {message.channel.send("Le mode lent est de " + amount + " seconde")
        return }
    } if(args[0] === amount + "min") {
        message.channel.setRateLimitPerUser(amount * 60)
        if(amount > 1) {
        message.channel.send("Le mode lent est de " + amount + " minutes")
        return
        } else { 
            message.channel.send("Le mode lent est de " + amount + " minute")   
             
    
    return }
    } if(args[0] === amount + "h") {
        message.channel.setRateLimitPerUser(amount * 60 * 60)
        if(amount > 1) {
        message.channel.send("Le mode lent est de " + amount + " heures")
        return
        } else {
            message.channel.send("Le mode lent est de " + amount + " heure")
        return}
    } else {
        message.channel.send("Vous pouvez utiliser que secondes(s), minutes(min) et les heures(h)")
    }

    };
module.exports.help = {
    name: "modelent",
    aliases: ["slowmode"],
    category: 'administrations',
    description: "Mettre le mode lent à partir d'une commande",
    usage: '<valeur + s/min/h>',
    args: false
}
