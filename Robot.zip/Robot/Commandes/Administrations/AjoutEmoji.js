const Discord = require("discord.js");
const { parse } = require("twemoji-parser");
const { MessageEmbed } = require("discord.js");

module.exports.run = (client, message, args) => {
    
    if (!message.member.hasPermission(`MANAGE_EMOJIS`)) {
      return message.channel.send(`Tu n'as pas les permissions !`)
    }
    
    const emoji = args[0];
    if (!emoji) return message.channel.send(`Donnes moi un emoji !`);

    let customemoji = Discord.Util.parseEmoji(emoji);

    if (customemoji.id) {
      const Link = `https://cdn.discordapp.com/emojis/${customemoji.id}.${
        customemoji.animated ? "gif" : "png"
      }`;
      const name = args.slice(1).join(" ");
      message.guild.emojis.create(
        `${Link}`,
        `${name || `${customemoji.name}`}`
      );
      const Added = new MessageEmbed()
        .setTitle(`Émoji ajouté`)
        .setDescription(
          `Un émoji a été ajouté ! | Nom : ${name || `${customemoji.name}`} | Aperçu : [Click Me](${Link})`
        );
      return message.channel.send(Added);
    } else {
      let CheckEmoji = parse(emoji, { assetType: "png" });
      if (!CheckEmoji[0])
        return message.channel.send(`Donnes moi un émoji valide .!`);
      message.channel.send(
        `Tu peux utiliser les émojis normaux sans ajouter sur le serveur !`
      );
    }
  };
module.exports.help = {
    name: "ajoutemoji",
    aliases: ["emojiadd"],
    category: 'administrations',
    description: "Ajoute un emoji à partir d'une commande",
    usage: '<emoji>',
    args: false
}