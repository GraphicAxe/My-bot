const Discord = module.require("discord.js");
const ms = require("ms"); //Make sure to install ms package

module.exports.run = (client, message, args) => {
        const time = args.join(" ");
        if (!time) {
        return message.channel.send("Veuillez entrer une valeur en `Secondes`, en `Minutes` ou en `Heures`")
        }
        if (!message.member.hasPermission("MANAGE_SERVER", "MANAGE_CHANNELS")) {
            return message.channel.send(`Aucune permisions`)
        }
        message.channel.overwritePermissions([
            {
               id: message.guild.id,
               deny : ['SEND_MESSAGES'],
            },
           ],);
           const embed = new Discord.MessageEmbed()
           .setTitle("Salon bloqué")
           .setDescription(`🔒 ${message.channel} à été bloqué`)
           message.channel.send(embed)

           let time1 = (`${time}`)
           setTimeout(function(){
           message.channel.overwritePermissions([
               {
               id: message.guild.id,
               null: ['SEND_MESSAGES'],
               },
            ],);
           const embed2 = new Discord.MessageEmbed()
           .setTitle("Salon débloqué")
           .setDescription(`🔒 ${message.channel} à été débloqué`)
           message.channel.send(embed2);
        }, ms(time1));
        message.delete();
    };
module.exports.help = {
    name: "tempbloquer",
    aliases: ["timelock"],
    category: 'administrations',
    description: "Bloqué temporairement un salon",
    usage: '<temps>',
    args: false
}