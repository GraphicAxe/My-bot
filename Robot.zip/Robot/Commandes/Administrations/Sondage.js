const Discord = require ('discord.js')

module.exports.run = async (client, message, args) => {
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("Vous devez avoir `Manage Messages` pour utilser cette commande")
 await message.delete()
  let say = message.content.split(" ").slice(1).join(" ")
  if(!say) return message.channel.send("Je ne peux pas répéter les messages vides.")

  let embed = new Discord.MessageEmbed()
  .setAuthor(message.guild.name, message.guild.iconURL())
  .setDescription(`${say}`)
  message.channel.send(embed).then(async msg => {
      await msg.react("✅"),
      await msg.react("❎");
  })
  
};
module.exports.help = {
    name: "sondage",
    aliases: ["sondage"],
    category: 'administrations',
    description: "Créer un embed à partir d'une commande",
    usage: '<texte>',
    args: false
}