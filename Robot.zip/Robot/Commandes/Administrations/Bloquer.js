const Discord = module.require("discord.js");

module.exports.run = async (client, message, args) => {
   if (!message.member.hasPermission('MANAGE_SERVER', 'MANAGE_CHANNELS')) {
   return message.channel.send("Aucune permissions.")
   }
   message.channel.overwritePermissions([
     {
        id: message.guild.id,
        deny : ['SEND_MESSAGES'],
     },
    ],);
   const embed = new Discord.MessageEmbed()
   .setTitle("Salon bloqué")
   .setDescription(`🔒 ${message.channel} à été bloqué`)
   await message.channel.send(embed);
   message.delete();
};
module.exports.help = {
    name: "bloquer",
    aliases: ["lock"],
    category: 'administrations',
    description: "Bloquer un salon",
    usage: '',
    args: false
}